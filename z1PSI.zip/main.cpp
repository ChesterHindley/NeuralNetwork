#include "Matrix.h"
#include <cassert>
#include <ranges>
#include "Model.h"
#include <fstream>

auto neuron(Matrix weights, Matrix input, int bias)
{
	return (weights * input)(0,0) + bias;
}

auto neural_network(Matrix weights, Matrix input)
{
	return weights * input;
}

// first element in vector of weights should be the layer closest to input (the hidden layer)
auto deep_neural_network(Matrix input, std::vector<Matrix> weights)
{
	auto ret = weights[0] * input;
	for (auto& weight : weights | std::ranges::views::drop(1))
		ret = weight * ret;
	return ret;
}

void testNeural()
{
	Matrix m1(
		{
			0.1,0.1,-0.3,
			0.1,0.2,0.0,
			0.0,0.7,0.1,
			0.2,0.4,0.0,
			-0.3,0.5,0.1
		}, 5, 3);
	Matrix m2({
		0.5,
		0.75,
		0.1
		}, 3, 1);
	assert(neural_network(m1, m2) == Matrix({ 0.095,0.2,0.535,0.4,0.235 }, 5, 1));

}
void testDeep()
{
	Matrix Wh(
		{
			0.1,0.1,-0.3,
			0.1,0.2,0.0,
			0.0,0.7,0.1,
			0.2,0.4,0.0,
			-0.3,0.5,0.1
		}, 5, 3);
	Matrix Wy(
		{
			0.7, 0.9,-0.4, 0.8, 0.1,
			0.8, 0.5, 0.3, 0.1, 0.0,
			-0.3, 0.9, 0.3, 0.1, -0.2
		}, 3, 5);
	
	Matrix input({
		0.5,
		0.75,
		0.1
		}, 3, 1);
	std::vector weights{ std::move(Wh),std::move(Wy) };
	assert(deep_neural_network(input, weights) == Matrix({
		0.376,
		0.3765,
		0.305
		}, 3, 1));
}
void testModel()
{
	std::ofstream("model.log").close(); 
	std::ofstream("log.txt").close();
	Model m;
	m.addLayer(5)
		.addLayer(3);
	Matrix res = m.predict(Matrix({1,2,3,2,2,1,2},7,1));

	std::cout << res;
	res.serialize("log.txt");
	res = Matrix::deserialize("log.txt");
	std::cout << res;
	m.serialize("model.log");
	m = Model::deserialize("model.log");
	m.serialize("modelcopy.log");

}


void chapter2()
{
	Matrix m1(
		{
			0.1,0.1,-0.3,
			0.1,0.2,0.0,
			0.0,0.7,0.1,
			0.2,0.4,0.0,
			-0.3,0.5,0.1
		}, 5, 3);
	Matrix input(
		{
			0.5,
			0.75,
			0.1,
		}, 3, 1);
	Matrix expected(
		{
			0.1,
			1.0,
			0.1,
			0.0,
			-0.1
		}, 5, 1);

	auto output = m1 * input;
	auto delta = 2.f / output.getRows() * (output - expected) * input.transpose();
	static constexpr double alpha = 0.01;
	m1 = m1 - alpha * delta;
	std::cout << m1;

}
void ch2task1()
{
	Model m;
	m.addLayer(1,0.5,0.5);
	Matrix expected({ 0.8 }, 1, 1);
	Matrix input({ 0.1 }, 1, 1);
	static constexpr double alpha = 1;

	for (int i = 0; i < 720; i++) {
		auto output = m.predict(input);
		std::cout << output(0,0) << ' ';
		auto delta = 2. / output.getRows() * (output - expected) * input.transpose();
		auto updatedWeights = m.getLayer(0) - alpha * delta;
		m.updateLayer(0, updatedWeights);
	}

	std::cout << m.predict(input);


}
void ch2t2()
{
	//3 wejscia 5 neuronow
	Model m;
	m.addLayer(5);
	Matrix input(
		{
			0.5,0.1,0.2,0.8,
			0.75,0.3,0.1,0.9,
			0.1,0.7,0.6,0.2
		}, 3, 4);
	Matrix expected({
		0.1,0.5,0.1,0.7,
		1.0,0.2,0.3,0.6,
		0.1,-0.5,0.2,0.2,
		0.0,0.3,0.9,-0.1,
		-0.1,0.7,0.1,0.8
		},5, 4);

	m.learn(1000,input, std::move(expected), 0.01);
	std::cout << m.predict(input);

}

int main()
{
	testNeural();
	testDeep();
	//testModel();
	//chapter2();
	//ch2task1();
	//ch2t2();


	
}